# Bildbeschreiber V3 – klassisches Bildanalyse-Puzzleteil

## Dateien
- `Bildbeschreiber-V3.html`: eigenständige Browser-Demo, lokal und ohne externe API.
- `classical-image-evidence.mjs`: isoliertes, wiederverwendbares Modul für regelbasierte Szenenhinweise.
- `classical-image-evidence.test.mjs`: kleine Regressionstests ohne externe Pakete.

## Einbindung
Die bestehende Pixelanalyse muss `m` mit diesen Feldern bereitstellen:
- `m.w`, `m.h`, `m.N`
- `m.px.hs`, `m.px.ss`, `m.px.ls`, `m.px.lum` als Arrays mit je `m.N` Einträgen.

Dann:
```js
import { analyzeClassicalEvidence } from './classical-image-evidence.mjs';
const evidence = analyzeClassicalEvidence(m);
```

`evidence.candidate` ist ausdrücklich nur ein Kandidat. `evidence.clues` enthält die messbaren Hinweise. `score` ist eine heuristische Regelübereinstimmung, keine kalibrierte Wahrscheinlichkeit.

## Testen
Mit Node.js 20+:
```bash
node --test classical-image-evidence.test.mjs
```

## Grenzen
Das Modul ist kein allgemeiner Objektdetektor und erkennt keine beliebigen Gegenstände zuverlässig. Es erkennt hier ein Muster aus einer großen, länglichen gelben Region, waagerechten Kanten im oberen Bildbereich, diagonalen Kanten unten und hoher mittlerer Struktur. Das passt zum bereitgestellten Bahnhof-/Zugbild und erzeugt dort den vorsichtigen Hinweis „Mögliche Bahnumgebung mit einem länglichen Fahrzeug“.

Es benennt bewusst nicht automatisch „Deutsche Bahn“, „Alstom“, Zugmodell, Bahnhof oder Zielanzeige. Solche Aussagen benötigen eigenständige Evidenzmodule (z. B. OCR für lesbaren Text, Logo-/Symbolprüfung oder eine deutlich umfangreichere regelbasierte Objektanalyse). Ein VLM/LLM, CNN, Transformer, neuronales Netz oder trainiertes Modell wird nicht verwendet.

## Reparaturen in V3
- dynamische Texte werden vor der HTML-Ausgabe escaped (XSS-Schutz für Texteingaben und Dateinamen)
- lokale Object-URLs werden beim Ersetzen/Entfernen von Bildern freigegeben
- Fehler beim Laden von Bildern räumen die Object-URL auf
- Clipboard-Fallback meldet einen Fehlschlag statt Erfolg vorzutäuschen
- technische Bildhinweise sind getrennt vom nutzerbestimmten Beschreibungstext
- automatische Szenenhinweise sind als heuristische Kandidaten gekennzeichnet
