/**
 * Klassische, regelbasierte Bildhinweise. Keine ML-/KI-Abhaengigkeit.
 * Input: m aus der analyze()-Funktion des Bildbeschreibers (w, h, N, px.hs/ss/ls/lum).
 * Output: vorsichtiger Kandidat + direkt messbare Hinweismerkmale.
 */
export function analyzeClassicalEvidence(m){
  const w=m.w,h=m.h,N=m.N,hs=m.px.hs,ss=m.px.ss,ls=m.px.ls,lum=m.px.lum;
  const mask=new Uint8Array(N);
  let yellowCount=0;
  for(let i=0;i<N;i++){
    // Gelb-/Goldbereich in HSL; bewusst breit, aber mit Mindestsaettigung.
    if(hs[i]>=35&&hs[i]<=68&&ss[i]>=0.32&&ls[i]>=0.24&&ls[i]<=0.92){mask[i]=1;yellowCount++;}
  }
  // Groesste zusammenhaengende gelbe Region (8er-Nachbarschaft).
  const seen=new Uint8Array(N), queue=new Int32Array(N);
  let best={area:0,minX:0,minY:0,maxX:0,maxY:0};
  for(let start=0;start<N;start++){
    if(!mask[start]||seen[start])continue;
    let head=0,tail=0;queue[tail++]=start;seen[start]=1;
    let minX=w,maxX=0,minY=h,maxY=0;
    while(head<tail){
      const i=queue[head++],x=i%w,y=(i/w)|0;
      if(x<minX)minX=x;if(x>maxX)maxX=x;if(y<minY)minY=y;if(y>maxY)maxY=y;
      for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){
        if(!dx&&!dy)continue;const nx=x+dx,ny=y+dy;
        if(nx<0||ny<0||nx>=w||ny>=h)continue;
        const ni=ny*w+nx;if(mask[ni]&&!seen[ni]){seen[ni]=1;queue[tail++]=ni;}
      }
    }
    if(tail>best.area)best={area:tail,minX,minY,maxX,maxY};
  }
  const bw=best.maxX-best.minX+1,bh=best.maxY-best.minY+1;
  const yellowArea=best.area/N,aspect=bw/Math.max(1,bh);
  // Kantenorientierungen in oberen und unteren Bildzonen.
  let topEdges=0,topHorizontal=0,bottomEdges=0,bottomDiagonal=0,midEdges=0;
  for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){
    const i=y*w+x,gx=lum[i+1]-lum[i-1],gy=lum[i+w]-lum[i-w];
    const mag=Math.abs(gx)+Math.abs(gy);if(mag<34)continue;
    const ax=Math.abs(gx),ay=Math.abs(gy),horizontalEdge=ay>ax*1.5;
    const diagonalEdge=ax>ay*0.35&&ay>ax*0.35;
    if(y<h*0.4){topEdges++;if(horizontalEdge)topHorizontal++;}
    if(y>h*0.55){bottomEdges++;if(diagonalEdge)bottomDiagonal++;}
    if(y>h*0.25&&y<h*0.75)midEdges++;
  }
  const topHorizontalRatio=topHorizontal/Math.max(1,topEdges);
  const bottomDiagonalRatio=bottomDiagonal/Math.max(1,bottomEdges);
  const elongatedYellow=yellowArea>0.018&&aspect>1.45;
  const overheadStructure=topEdges/(w*h*0.4)>0.018&&topHorizontalRatio>0.28;
  const trackLikeStructure=bottomEdges/(w*h*0.45)>0.018&&bottomDiagonalRatio>0.18;
  const denseMidStructure=midEdges/(w*h*0.5)>0.025;
  let railScore=0;
  if(elongatedYellow)railScore+=0.38;
  if(overheadStructure)railScore+=0.25;
  if(trackLikeStructure)railScore+=0.22;
  if(denseMidStructure)railScore+=0.15;
  const clues=[];
  if(elongatedYellow)clues.push('große, langgestreckte gelbe Farbregion');
  if(overheadStructure)clues.push('viele überwiegend waagerechte Kanten im oberen Bildbereich');
  if(trackLikeStructure)clues.push('diagonal verlaufende Kanten im unteren Bildbereich');
  if(denseMidStructure)clues.push('hohe Kanten- und Strukturmenge im mittleren Bildbereich');
  let candidate='';
  if(railScore>=0.68)candidate='Mögliche Bahnumgebung mit einem länglichen Fahrzeug';
  else if(elongatedYellow)candidate='Große, längliche gelbe Objektregion';
  return {candidate,score:Math.min(0.95,railScore),clues,yellowArea,aspect,topHorizontalRatio,bottomDiagonalRatio};
}
