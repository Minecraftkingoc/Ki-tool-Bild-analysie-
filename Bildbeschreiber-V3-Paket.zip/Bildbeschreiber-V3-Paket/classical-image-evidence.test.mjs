import test from 'node:test';
import assert from 'node:assert/strict';
import { analyzeClassicalEvidence } from './classical-image-evidence.mjs';

test('neutral image does not produce a railway candidate', () => {
  const n=120*80;
  const m={w:120,h:80,N:n,px:{hs:new Float32Array(n).fill(120),ss:new Float32Array(n).fill(.4),ls:new Float32Array(n).fill(.4),lum:new Float32Array(n).fill(100)}};
  assert.equal(analyzeClassicalEvidence(m).candidate,'');
});

test('elongated yellow region plus line structures yields only a tentative railway hint', () => {
  const w=120,h=80,N=w*h;
  const hs=new Float32Array(N).fill(210), ss=new Float32Array(N).fill(.1), ls=new Float32Array(N).fill(.5), lum=new Float32Array(N).fill(100);
  // Simulated large yellow, elongated region.
  for(let y=20;y<48;y++) for(let x=12;x<88;x++){const i=y*w+x;hs[i]=48;ss[i]=.8;ls[i]=.55;}
  // Strong structured edge evidence in upper and lower zones.
  for(let y=2;y<15;y++) for(let x=0;x<w;x++) lum[y*w+x]=(y%2?210:20);
  for(let y=50;y<h-2;y++) for(let x=2;x<w-2;x++) lum[y*w+x]=((x+y)%3?220:10);
  const result=analyzeClassicalEvidence({w,h,N,px:{hs,ss,ls,lum}});
  assert.match(result.candidate,/Mögliche Bahnumgebung/);
  assert.ok(result.score>=.68);
});
